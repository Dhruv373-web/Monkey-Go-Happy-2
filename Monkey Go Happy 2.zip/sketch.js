var monkey = createSprite(65,369, 10,40);
monkey.setAnimation("monkey");
monkey.scale = 0.2;
monkey.x = 50;

var ground = createSprite(70,380,10,40);
ground.x = ground.width /2;


var bananaGroup = createGroup();
var obstacleGroup = createGroup();

var count = 0;

var invisibleGround = createSprite(200,385,400,5);
invisibleGround.visible = false;


function draw() {
  background("white");
  ground.velocityX = -6;
  //monkey.velocityX = 6;



function spawnBananas (){
   if(World.frameCount % 80 === 0) {
    var banana = createSprite(400,365,10,40);
    banana.velocityX = - 3;
    banana.setAnimation("banana");
    
    banana.scale = 0.25;
    banana.lifetime = 134;
  
    bananaGroup.add(banana);
  }
}
function spawnObstacles(){
  if (World.frameCount % 300 === 0) {
    var obstacle = createSprite(400,320,40,10);
    obstacle.y = randomNumber(1400,240);
    obstacle.setAnimation("rock");
    obstacle.scale = 0.5;
    obstacle.velocityX =-(6 + 3*count/100);

    
    obstacle.lifetime = 70;
    
    
    obstacle.depth = monkey.depth;
    monkey.depth = monkey.depth + 1;
    
    obstacleGroup.add(obstacle);

  }
}+
  
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  if(keyDown("space") ){
   monkey.velocityY = -12 ;
  }
 monkey.velocityY = monkey.velocityY + 0.8;
 ground.velocityX = -(6 + 3*count/100);

 text("score:"+ count, 300,50);
    
  if(bananaGroup.isTouching(monkey)){
    count= count + 1; 
  }
     spawnBananas();
     spawnObstacles();
     
     monkey.collide(invisibleGround);

  if (bananaGroup.isTouching(sword)
      count = count +2;
      }
  else {
   monkey.scale = 0.1;
  drawSprites();
}